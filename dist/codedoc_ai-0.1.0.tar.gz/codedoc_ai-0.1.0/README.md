# 🚀 CodeDoc AI - Smart Documentation Generator

**The Future of Code Documentation is Here!**

Automatically generate beautiful, interactive documentation with AI-powered examples for any Python codebase.

## ✨ Features

- 🤖 **AI-Powered Examples** - Generates real-world usage examples
- 📚 **Interactive Documentation** - Beautiful HTML/Markdown output
- ⚡ **Lightning Fast** - Parses your code in seconds
- 🎯 **Smart Analysis** - Understands context and generates relevant examples
- 🌐 **Multiple Languages** - Starting with Python, expanding to more languages

## 🎯 Vision

Making documentation so good that developers actually want to read it!

## 🚀 Quick Start

```bash
pip install codedoc-ai
codedoc generate ./your_project
```

## 💡 Example

**Input Code:**
```python
def calculate_discount(price, discount_percent):
    """Calculate discount amount"""
    return price * (discount_percent / 100)
```

**Generated Documentation:**
- Beautiful formatted docs
- Real usage examples
- Parameter explanations
- Edge case handling

---

*Built with ❤️ for developers worldwide* 🌍 